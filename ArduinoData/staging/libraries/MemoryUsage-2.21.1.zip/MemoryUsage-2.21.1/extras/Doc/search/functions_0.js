var searchData=
[
  ['mu_5ffreeram',['mu_freeRam',['../MemoryUsage_8cpp.html#aa45c642e8bcfc9a9ea40cd9bcf6ec9fb',1,'mu_freeRam():&#160;MemoryUsage.cpp'],['../MemoryUsage_8h.html#af1d664ba74789fffa406a0ff1cea8bdc',1,'mu_freeRam(void):&#160;MemoryUsage.h']]],
  ['mu_5fstackcount',['mu_StackCount',['../MemoryUsage_8cpp.html#a7c6166d997f1d7cc6a281f3569c103c3',1,'mu_StackCount(void):&#160;MemoryUsage.cpp'],['../MemoryUsage_8h.html#a7c6166d997f1d7cc6a281f3569c103c3',1,'mu_StackCount(void):&#160;MemoryUsage.cpp']]],
  ['mu_5fstackpaint',['mu_StackPaint',['../MemoryUsage_8cpp.html#ad5d0402770163c43aafc9d9f1e20a3fd',1,'MemoryUsage.cpp']]]
];
